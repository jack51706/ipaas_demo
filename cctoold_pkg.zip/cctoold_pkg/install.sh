#!/bin/bash
if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root" 1>&2
  exit 1
fi

echo "What is user's tenant?"
read user_tenant
echo "What is your collector IP? (default: 127.0.0.1)" 
read collector_ip
if [[ $collector_ip == "" ]]; then
    collector_ip="127.0.0.1"
fi
echo "What is your proxy port? (default: 80)"
read proxy_port
if [[ $proxy_port == "" ]]; then
    proxy_port="80"
fi
echo "What is your portal IP/URL? (default: portal.corecloud.com.tw)"
read portal_location
if [[ $portal_location == "" ]]; then
    portal_location="portal.corecloud.com.tw"
fi
echo "What is your portal port? (default: 443)"
read portal_port
if [[ $portal_port == "" ]]; then
    portal_port="443"
fi
echo "What is password of your Cloudera ADMIN account? (default: admin)"
read -s cloudera_pw
if [[ $cloudera_pw == "" ]]; then
    cloudera_pw="admin"
fi
echo "Try to get flume role id..." 
flume_role_id=""
export PYTHONIOENCODING=utf8
idx=3
curl -s "https://127.0.0.1:7183/j_spring_security_check" --insecure -c cookie.txt -d "j_username=admin&j_password=$cloudera_pw" --header "Content-Type: application/x-www-form-urlencoded; charset=UTF-8"
while [ $idx -le 20 ];
do
	flume_role_id=$(curl -s "https://127.0.0.1:7183/cmf/services/$idx/instances/instancesOverview.json" --insecure -b cookie.txt | python -c "import sys, json; result=json.load(sys.stdin); print result['instances'][0]['id'] if 'availableRoleTypes' in result and 'CT_COLLECTOR' in result['availableRoleTypes'] else '';")
	if [[ $flume_role_id != "" ]]; then
		break
	fi
	((idx++))
done
if [[ $flume_role_id == "" ]]; then
	echo "Can't automatically get flume role ID! What is your flume role ID?"
	read $flume_role_id
	if [[ $flume_role_id == "" ]]; then
		echo "Installation stops because flume role ID is not specified!"
		exit 1
	fi
fi

echo "Below is what you enter:"
echo "COLLECTOR IP: $collector_ip"
echo "PROXY PORT: $proxy_port"
echo "PORTAL LOCATION: $portal_location"
echo "PORTAL PORT: $portal_port"
echo "FLUME ROLE ID: $flume_role_id"
echo "Are you sure? (Y/N)"
read ans
if [[ $ans != "Y" ]] && [[ $ans != "y" ]]; then
	echo "Installation Interrupted!"
	exit 1
fi

mkdir /var/cctoold
cp cctool.jar /var/cctoold/
cp cctoold.keystore /var/cctoold/
cp configuration.prop /var/cctoold/
cp collector_checker.py /var/cctoold/
cp cctoold /etc/init.d/cctoold

# replace collector port in configuration.prop
sed -i -e "s/<PROXY_PORT>/$proxy_port/g" /var/cctoold/configuration.prop
# replace portal location in configuration.prop
sed -i -e "s/<PORTAL_LOCATION>/$portal_location/g" /var/cctoold/configuration.prop
# replace portal port in configuration.prop
sed -i -e "s/<PORTAL_PORT>/$portal_port/g" /var/cctoold/configuration.prop
# replace user tenant in configuration.prop
sed -i -e "s/<USER_TENANT>/$user_tenant/g" /var/cctoold/configuration.prop
# replace collector port in cctoold
sed -i -e "s/<PROXY_PORT>/$proxy_port/g" /etc/init.d/cctoold
# replace data in collector_checker.py
sed -i -e "s/<COLLECTOR_IP>/$collector_ip/g" /var/cctoold/collector_checker.py 
sed -i -e "s/<COLLECTOR_SENTINEL_ROLE_ID>/$flume_role_id/g" /var/cctoold/collector_checker.py
sed -i -e "s/<COLLECTOR_CLOUDERA_API_VERSION>/v12/g" /var/cctoold/collector_checker.py
sed -i -e "s/<COLLECTOR_CLOUDERA_ADMIN_PW>/$cloudera_pw/g" /var/cctoold/collector_checker.py

chmod 755 /etc/init.d/cctoold
chkconfig --add cctoold
chkconfig --level 3 cctoold on
service cctoold start

# schedule collector_checker
crontab -l > mycron
echo "*/5 * * * * python /var/cctoold/collector_checker.py >> /home/admin/checker.log" > mycron
crontab mycron
rm mycron

echo "Installation complete!"
