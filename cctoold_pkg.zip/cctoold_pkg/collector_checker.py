#!/usr/local/bin/python2.7
import urllib2
import urllib
import requests
import time
import smtplib, httplib
import json
from email.mime.text import MIMEText
from datetime import datetime
from base64 import b64encode
import sys

collectors=[
	["<COLLECTOR_IP>","admin","<COLLECTOR_CLOUDERA_ADMIN_PW>","<COLLECTOR_SENTINEL_ROLE_ID>","<COLLECTOR_CLOUDERA_API_VERSION>"],
	]

def getJSON(host, port, user, password, url, content, method="GET"):
	print url
	conn = httplib.HTTPSConnection(host, int(port))
	encoded = b64encode(bytes(user+":"+password))
	getheaders = {'Authorization' : 'Basic '+encoded, 'Content-Type':'application/json'}
	if method=="POST":
		if content is None:
			content=json.dumps({})
		conn.request("POST", url, body=content ,headers=getheaders)
	else:
		conn.request("GET", url, headers=getheaders)
	res = conn.getresponse()
	resStr=res.read()
	try:
		print "success:"+resStr
		return json.loads(resStr)
	except:
		print "fail:"+resStr
		return json.loads("{}")

def restartCluster(ip, port, account, password, apiVer):
        resp=getJSON(ip, port, account, password, "/api/v"+apiVer+"/clusters/Cluster%201/commands")
        ongoing=False
        print "command status: "+`resp`
        if "items" in resp:
                for item in resp['items']:
                        if "name" in item and item["name"]=="Restart":
                            ongoing=True
                            break
        #ongoing=True
        if not ongoing:
                resp=getJSON(ip, port, account, password, "/api/v"+apiVer+"/clusters/Cluster%201/commands/restart", json.dumps({"restartOnlyStaleServices":False}) , "POST" )
                print "restart done!"
                return True
        else:
                print "previous restart command is not finished yet!"
                return False

timeNow=int(time.time()*1000)
timeStart=timeNow-5*60*1000
print timeNow
print timeStart
for collector in collectors:
	with requests.Session() as collectSession:
		resp=collectSession.get("https://"+collector[0]+":7183/cmf/", verify=False)
		data={"j_username":collector[1], "j_password":collector[2]}
		ret=collectSession.post("https://"+collector[0]+":7183/j_spring_security_check", data=data, verify=False)
		col_headers = {
			'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:28.0) Gecko/20100101 Firefox/28.0',
			'Accept': 'application/json, text/javascript, */*; q=0.01',
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'X-Requested-With': 'XMLHttpRequest',
			'referer' : 'https://'+collector[0]+':7183/cmf/process/all/logs/search'
			}
		collector_patterns=[
			"org.apache.flume.ChannelFullException: The channel has reached it's capacity"
		]
		for collector_pattern in collector_patterns:
			data1={"start":`timeStart`, "end":`timeNow`, "offset":"0", "num":"100", "timeout":"60", "query":collector_pattern, "level":"ERROR", "roleids":collector[3], "requestStartTime":`timeNow`}
			resp=collectSession.post("https://"+collector[0]+":7183/cmf/process/all/logs/search/api", data=urllib.urlencode(data1), verify=False, headers=col_headers)
			print "[data]: "+`data1`
			print "[collector "+collector[0]+"]: "+resp.text
			jResp=json.loads(resp.text)
			if len(jResp["results"])>0:
				if collector_patterns.index(collector_pattern)==0:
					restartCluster(collector[0], "7183", collector[1], collector[2], collector[4])
				print "I observed "+`len(jResp["results"])`+" error log pattern ["+collector_pattern+"] on collector "+collector[0]
